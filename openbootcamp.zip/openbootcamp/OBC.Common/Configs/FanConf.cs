// This file is part of OpenBootCamp.
// Copyright © Sparronator9999 2024-2026.
//
// OpenBootCamp is free software: you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version.
//
// OpenBootCamp is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
// or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along with
// OpenBootCamp. If not, see <https://www.gnu.org/licenses/>.

using MessagePack;
using System.Xml.Serialization;

namespace OBC.Common.Configs;

[MessagePackObject]
public sealed class FanConf
{
    /// <summary>
    /// Should OBC control this fan?
    /// </summary>
    /// <remarks>
    /// <para>
    /// If <see langword="true"/>, this fan's speed will be set by
    /// OBC will using the other settings in this <see cref="FanConf"/>.
    /// </para>
    /// <para>
    /// If <see langword="false"/>, this fan's speed will be
    /// controlled by the SMC (system default).
    /// </para>
    /// </remarks>
    [XmlElement]
    [Key(0)]
    public bool Enabled { get; set; }

    /// <summary>
    /// The SMC key for the sensor that controls this fan's speed.
    /// </summary>
    [XmlElement]
    [Key(1)]
    public string SensorKey { get; set; } = string.Empty;

    /// <summary>
    /// The sensor temperature that sets this fan's minimum speed.
    /// </summary>
    [XmlElement]
    [Key(2)]
    public float Tmin { get; set; }

    /// <summary>
    /// The sensor temperature that sets this fan's maximum speed.
    /// </summary>
    [XmlElement]
    [Key(3)]
    public float Tmax { get; set; }

    /// <summary>
    /// How much the sensor's temperature needs to drop by after
    /// peaking before selecting a lower speed.
    /// </summary>
    /// <remarks>
    /// For example, with the default setting of 5°, if a sensor reaches
    /// 60°, the "effective" temperature used to calculate fan RPM wouldn't
    /// begin lowering until the "real" temperature drops below 55°.
    /// </remarks>
    [XmlElement]
    [Key(4)]
    public float Tdown { get; set; } = 5;
}
